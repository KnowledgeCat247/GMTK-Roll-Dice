var energyDice=new Dice('energyDice',1,1000,'amogus',(n,i)=>n+i);
var moveDice=new Dice('moveDice',1,10,'amogus',(n,i)=>n+i);
energyDice.appendTo(body);
moveDice.appendTo(body);
window.oncontextmenu=e=>{
  e.preventDefault();
  energyDice.roll(60000);
  moveDice.roll(60000);
}
window.onclick=e=>{
  energyDice.rolling=false;
  moveDice.rolling=false;
}
/*var currentDice;
var currentSave;
var attacker=new Dice('attackDice1',1,6,'attackDice',(n,i)=>n+i);
var defer=new Dice('defDice1',1,6,'defDice',(n,i)=>n+i);
var mover=new Dice('moveDice1',1,6,'moveDice',(n,i)=>n+i);
var allin=new Dice('allInDice1',1,6,'AllInDice',(n,i)=>n+i);
var dices=[attacker,defer,mover,allin];
for (var i = 0; i < dices.length; i++) {
  dices[i].appendTo(body);
}

function useSave() {
  if (currentSave===moveCurrentSave) {
    mover.value=moveCurrentSave.value;
    mover.updateView();
    moveCurrentSave.value=0;
    moveCurrentSave.updateView();
  }
  if (currentSave===moveCurrentSave) {
    defer.value=defCurrentSave.value;
    defer.updateView();
    defCurrentSave.value=0;
    defCurrentSave.updateView();
  }
  if (currentSave===moveCurrentSave) {
    allin.value=allinCurrentSave.value;
    allin.updateView();
    allinCurrentSave.value=0;
    allinCurrentSave.updateView();
  }
  if (currentSave===attackCurrentSave) {
    attacker.value=attackCurrentSave.value;
    attacker.updateView();
    attackCurrentSave.value=0;
    attackCurrentSave.updateView();
  }
}

var saved=true;
var attackSaveCount=2;
var defSaveCount=2;
var moveSaveCount=2;
var allinSaveCount=2;

var attackSaves=[];
var attackCurrentSave;
for (var i = 0; i < attackSaveCount; i++) {
  attackSaves[i]=new Card(`attackSave${i+1}`,attacker,'attackSave');
  attackSaves[i].appendTo(getElement("#attackStack"));
}
var defSaves=[];
var defCurrentSave;
for (var i = 0; i < defSaveCount; i++) {
  defSaves[i]=new Card(`defSave${i+1}`,defer,'defSave');
  defSaves[i].appendTo(getElement("#defStack"));
}
var moveSaves=[];
var moveCurrentSave;
for (var i = 0; i < moveSaveCount; i++) {
  moveSaves[i]=new Card(`moveSave${i+1}`,mover,'moveSave');
  moveSaves[i].appendTo(getElement("#moveStack"));
}
var allinSaves=[];
var allinCurrentSave;
for (var i = 0; i < allinSaveCount; i++) {
  allinSaves[i]=new Card(`allinSave${i+1}`,allin,'allinSave');
  allinSaves[i].appendTo(getElement("#MegaBuffStack"));
}

window.onclick=e=>{
  if (currentDice) {
    currentDice.rolling=false;
  }
  if (e.target.classList.contains("attackSave")) {
    attackCurrentSave=attackSaves.find(as=>as.name===e.target.id);
    currentSave=attackCurrentSave;
    console.log(attackCurrentSave);
  }
  if (e.target.classList.contains("defSave")) {
    defCurrentSave=defSaves.find(ds=>ds.name===e.target.id);
    currentSave=defCurrentSave;
    console.log(defCurrentSave);
  }
  if (e.target.classList.contains("moveSave")) {
    moveCurrentSave=moveSaves.find(ms=>ms.name===e.target.id);
    currentSave=moveCurrentSave;
    console.log(moveCurrentSave);
  }
  if (e.target.classList.contains("allinSave")) {
    allinCurrentSave=allinSaves.find(alls=>alls.name===e.target.id);
    currentSave=allinCurrentSave;
    console.log(allinCurrentSave);
  }
  if (e.target.classList.contains("dice")) {
    currentDice=dices.find(d=>d.name===e.target.id)
  }
}
window.oncontextmenu=e=>{
  e.preventDefault();
  currentDice.roll(6);
  saved=false;
}
window.ondblclick=e=>{
  if (!saved) {
    if (attackCurrentSave) {
      attackCurrentSave.save();
    }
    if (defCurrentSave) {
      defCurrentSave.save();
    }
    if (moveCurrentSave) {
      moveCurrentSave.save();
    }
    if (allinCurrentSave) {
      if (allin.value===2||allin.value===0) {
        allinCurrentSave.save();
      }
    }
    saved=true;
  }
}*/
