var speed=1;
var energy=1000;
var attack=1;
var fallspeed=10;
var points=0;
var map=(cp)=>false;
var wall=(x,y,cp)=>rectangleCollision2D(Vector(x,y),Vector(100,100),cp);
var intrvl=setInterval(function () {
  moving(speed*100,150,map);
  if (player.y>0) {
    player.y-=fallspeed;
    fallspeed+=5;
  }else {
    fallspeed=10;
    player.y=0;
  }
  if (keys["e"]||keys["E"]) {
    speed+=moveDice.value;
    energy+=energyDice.value;
    moveDice.value=0;
    energyDice.value=0;
    energyDice.updateView();
    moveDice.updateView();
  }
  speed-=5;
  energy-=5;
  if (energy<=0) {
    alert("end. points: "+points);
    clearInterval(intrvl);
  }else {
    let ky=Math.random()*1000>500 ? "a" : "d";
    getElement(".aaa").innerHTML=ky;
    if (keys[ky]) {
      points+=1;
    }
  }
}, 100);
