var keys={};
var player={
  y: 0,
  x: 100
};

document.querySelector('#player').style.left = player.x+"px";
document.querySelector('#game').style.left = -player.x+"px";

document.onkeydown = event => {
  event.preventDefault();
  keys[event.key]=true;
  console.log(keys);
}
document.onkeyup = event => {
  delete keys[event.key];
  console.log(keys);
}
function moving(speed,jumpHigh,mapCollision) {
  if ((keys["a"]||keys["A"])&&(!mapCollision(player))) {
      player.x -= speed;
      if (mapCollision(player)) {
        player.x += speed;
      }
  }
  if ((keys["d"]||keys["D"])&&(!mapCollision(player))) {
      player.x += speed;
      if (mapCollision(player)) {
        player.x -= speed;
      }
  }
  if ((keys[" "])&&(!mapCollision(player))) {
      player.y+=jumpHigh;
  }
  document.querySelector('#player').style.bottom = player.y+"px";
  document.querySelector('#player').style.left = player.x+"px";
  document.querySelector('#game').style.left = innerWidth/2-50-player.x+"px";
}
