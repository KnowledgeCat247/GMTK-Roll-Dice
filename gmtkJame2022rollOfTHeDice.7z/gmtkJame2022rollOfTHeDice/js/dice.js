class Dice {
  constructor(name,initalNum,sidesCount,group,sideFunc) {
    this.name=name;
    this.sidesCount=sidesCount;
    this.initalNum=initalNum;
    this.sideFunc=sideFunc;
    this.group=group;
    this.value=initalNum;
    this.rolling=false;
  }
  appendTo(el) {
    this.html=`
    <div class="dice ${this.group}" id=${this.name}>${this.value}</div>`;
    el.innerHTML+=this.html;
  }
  roll(power){
    this.rolling=true;
    this.interval=setInterval(()=>{
      if (this.rolling) {
        this.value=Math.floor(Math.random()*this.sidesCount)+1;
        console.log(this.value);
        getElement("#"+this.name).innerHTML=this.value;
      }else {
        clearInterval(this.interval);
      }
    },1000/power);
  }
  updateView(){
    getElement("#"+this.name).innerHTML=this.value;
  }
}
